package com.chiles.practica_activities

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var btnNext: ImageView
    lateinit var btnBack: ImageView
    lateinit var txtInfo: TextView
    lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
    }

    private fun initViews() {
        btnNext = findViewById(R.id.imgNext)
        btnBack = findViewById(R.id.imgBack)
        txtInfo = findViewById(R.id.txtDetail)
        imageView = findViewById(R.id.imgPrincipal)
    }

    fun more(view: View) {
        startActivity(Intent(this, imageDetail::class.java).apply {
            putExtra("hola", Image.arrayImages.get(0))
        })
    }

}